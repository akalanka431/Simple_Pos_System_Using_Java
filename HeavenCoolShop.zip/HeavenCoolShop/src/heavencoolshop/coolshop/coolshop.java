/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heavencoolshop.coolshop;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ASUS
 */
public class coolshop extends javax.swing.JFrame implements MouseListener {

    /**
     * Creates new form coolshop
     */
    public coolshop() {
        initComponents();
        
        lcho.addMouseListener(this);
        lvan.addMouseListener(this);
        lman.addMouseListener(this);
        lmix.addMouseListener(this);
        lstaw.addMouseListener(this);
        coke.addMouseListener(this);
        pepsi.addMouseListener(this);
        sprite.addMouseListener(this);
        fanta.addMouseListener(this);
        dew.addMouseListener(this);
        
        jTable1.setForeground(Color.YELLOW);
        jTable1.setBackground(Color.BLACK);
        jTable1.setOpaque(false);
        jTable1.setFont(new Font("jarif",Font.BOLD,14));
    }

    DefaultTableModel model = new DefaultTableModel();
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        coke = new javax.swing.JLabel();
        sprite = new javax.swing.JLabel();
        dew = new javax.swing.JLabel();
        pepsi = new javax.swing.JLabel();
        fanta = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        lstaw = new javax.swing.JLabel();
        lcho = new javax.swing.JLabel();
        lvan = new javax.swing.JLabel();
        lman = new javax.swing.JLabel();
        lmix = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel12 = new javax.swing.JLabel();
        txtsub = new javax.swing.JTextField();
        btndelete = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 204, 204));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jLabel1.setText("Cool Drinks Shop");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(526, 526, 526)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(25, 25, 25))
        );

        coke.setIcon(new javax.swing.ImageIcon(getClass().getResource("/heavencoolshop/coolshop/coke.png"))); // NOI18N

        sprite.setIcon(new javax.swing.ImageIcon("C:\\Users\\ASUS\\Documents\\NetBeansProjects\\HeavenCoolShop\\img\\sprite.jpg")); // NOI18N

        dew.setIcon(new javax.swing.ImageIcon(getClass().getResource("/heavencoolshop/coolshop/dew.jpg"))); // NOI18N

        pepsi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/heavencoolshop/coolshop/pepsi.jpg"))); // NOI18N

        fanta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/heavencoolshop/coolshop/fanta.jpg"))); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(coke, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 53, Short.MAX_VALUE)
                .addComponent(pepsi, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(sprite, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(fanta, javax.swing.GroupLayout.PREFERRED_SIZE, 249, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(dew)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(dew, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(fanta, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sprite, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pepsi, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(coke, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Cool Drinks", jPanel2);

        lstaw.setIcon(new javax.swing.ImageIcon(getClass().getResource("/heavencoolshop/coolshop/index3.jpg"))); // NOI18N

        lcho.setIcon(new javax.swing.ImageIcon(getClass().getResource("/heavencoolshop/coolshop/index.jpg"))); // NOI18N

        lvan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/heavencoolshop/coolshop/index1.jpg"))); // NOI18N

        lman.setIcon(new javax.swing.ImageIcon(getClass().getResource("/heavencoolshop/coolshop/index2.jpg"))); // NOI18N

        lmix.setIcon(new javax.swing.ImageIcon(getClass().getResource("/heavencoolshop/coolshop/index5.jpg"))); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lcho, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addComponent(lvan)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 65, Short.MAX_VALUE)
                .addComponent(lman)
                .addGap(38, 38, 38)
                .addComponent(lmix, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(lstaw, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lmix, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lman, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lvan, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lstaw, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lcho, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Ice Cream", jPanel3);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item", "price", "Quantity", "total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel12.setText("Total");

        txtsub.setBackground(new java.awt.Color(0, 0, 0));
        txtsub.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        txtsub.setForeground(new java.awt.Color(255, 255, 255));

        btndelete.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btndelete.setText("delete");
        btndelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndeleteActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton1.setText("Sales End");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTabbedPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 630, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(108, 108, 108)
                        .addComponent(jLabel12)
                        .addGap(43, 43, 43)
                        .addComponent(txtsub, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(136, 136, 136)
                .addComponent(btndelete, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(73, 73, 73)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(134, 134, 134)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(txtsub, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 45, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btndelete, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btndeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndeleteActionPerformed
        // TODO add your handling code here:
        model.removeRow(jTable1.getSelectedRow());
        int sum = 0;
        for(int a=0;a<jTable1.getRowCount(); a++){
            sum = sum + Integer.parseInt(jTable1.getValueAt(a, 3).toString());
        }
        txtsub.setText(Integer.toString(sum));
    }//GEN-LAST:event_btndeleteActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        model.setNumRows(0);
        txtsub.setText("");
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(coolshop.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(coolshop.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(coolshop.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(coolshop.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new coolshop().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btndelete;
    private javax.swing.JLabel coke;
    private javax.swing.JLabel dew;
    private javax.swing.JLabel fanta;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lcho;
    private javax.swing.JLabel lman;
    private javax.swing.JLabel lmix;
    private javax.swing.JLabel lstaw;
    private javax.swing.JLabel lvan;
    private javax.swing.JLabel pepsi;
    private javax.swing.JLabel sprite;
    private javax.swing.JTextField txtsub;
    // End of variables declaration//GEN-END:variables

    @Override
    public void mouseClicked(MouseEvent e) {
        
        if(e.getSource() == lcho){
            String name = "Choclate";
            int price = 45;
            
            int quantity = Integer.parseInt(JOptionPane.showInputDialog("Enter the Quantity"));
            int tot = price * quantity;
            
            model = (DefaultTableModel)jTable1.getModel();
            model.addRow(new Object[]{
                name,
                price,
                quantity,
                tot,
            });
            int sum = 0;
            for(int i=0; i < jTable1.getRowCount(); i++){
                sum = sum + Integer.parseInt(jTable1.getValueAt(i, 3).toString());
            }
             txtsub.setText(Integer.toString(sum));
        }
        else if(e.getSource() == lvan){
             String name = "Vanila";
            int price = 40;
            
            int quantity = Integer.parseInt(JOptionPane.showInputDialog("Enter the Quantity"));
            int tot = price * quantity;
            
            model = (DefaultTableModel)jTable1.getModel();
            model.addRow(new Object[]{
                name,
                price,
                quantity,
                tot,
            });
            int sum = 0;
            for(int i=0; i < jTable1.getRowCount(); i++){
                sum = sum + Integer.parseInt(jTable1.getValueAt(i, 3).toString());
            }
             txtsub.setText(Integer.toString(sum));
        }
        else if(e.getSource() == lman){
             String name = "Mango";
            int price = 50;
            
            int quantity = Integer.parseInt(JOptionPane.showInputDialog("Enter the Quantity"));
            int tot = price * quantity;
            
            model = (DefaultTableModel)jTable1.getModel();
            model.addRow(new Object[]{
                name,
                price,
                quantity,
                tot,
            });
            int sum = 0;
            for(int i=0; i < jTable1.getRowCount(); i++){
                sum = sum + Integer.parseInt(jTable1.getValueAt(i, 3).toString());
            }
             txtsub.setText(Integer.toString(sum));
        }
        else if(e.getSource() == lmix){
             String name = "MixFruit";
            int price = 70;
            
            int quantity = Integer.parseInt(JOptionPane.showInputDialog("Enter the Quantity"));
            int tot = price * quantity;
            
            model = (DefaultTableModel)jTable1.getModel();
            model.addRow(new Object[]{
                name,
                price,
                quantity,
                tot,
            });
            int sum = 0;
            for(int i=0; i < jTable1.getRowCount(); i++){
                sum = sum + Integer.parseInt(jTable1.getValueAt(i, 3).toString());
            }
             txtsub.setText(Integer.toString(sum));
        }
        else if(e.getSource() == lstaw){
             String name = "MixFruit";
            int price = 75;
            
            int quantity = Integer.parseInt(JOptionPane.showInputDialog("Enter the Quantity"));
            int tot = price * quantity;
            
            model = (DefaultTableModel)jTable1.getModel();
            model.addRow(new Object[]{
                name,
                price,
                quantity,
                tot,
            });
            int sum = 0;
            for(int i=0; i < jTable1.getRowCount(); i++){
                sum = sum + Integer.parseInt(jTable1.getValueAt(i, 3).toString());
            }
             txtsub.setText(Integer.toString(sum));
        }
        else if(e.getSource() == coke){
             String name = "Cocacola";
            int price = 70;
            
            int quantity = Integer.parseInt(JOptionPane.showInputDialog("Enter the Quantity"));
            int tot = price * quantity;
            
            model = (DefaultTableModel)jTable1.getModel();
            model.addRow(new Object[]{
                name,
                price,
                quantity,
                tot,
            });
            int sum = 0;
            for(int i=0; i < jTable1.getRowCount(); i++){
                sum = sum + Integer.parseInt(jTable1.getValueAt(i, 3).toString());
            }
             txtsub.setText(Integer.toString(sum));
        }
        else if(e.getSource() == pepsi){
             String name = "Pepsi";
            int price = 70;
            
            int quantity = Integer.parseInt(JOptionPane.showInputDialog("Enter the Quantity"));
            int tot = price * quantity;
            
            model = (DefaultTableModel)jTable1.getModel();
            model.addRow(new Object[]{
                name,
                price,
                quantity,
                tot,
            });
            int sum = 0;
            for(int i=0; i < jTable1.getRowCount(); i++){
                sum = sum + Integer.parseInt(jTable1.getValueAt(i, 3).toString());
            }
             txtsub.setText(Integer.toString(sum));
        }
        else if(e.getSource() == sprite){
             String name = "Sprite";
            int price = 70;
            
            int quantity = Integer.parseInt(JOptionPane.showInputDialog("Enter the Quantity"));
            int tot = price * quantity;
            
            model = (DefaultTableModel)jTable1.getModel();
            model.addRow(new Object[]{
                name,
                price,
                quantity,
                tot,
            });
            int sum = 0;
            for(int i=0; i < jTable1.getRowCount(); i++){
                sum = sum + Integer.parseInt(jTable1.getValueAt(i, 3).toString());
            }
             txtsub.setText(Integer.toString(sum));
        }
        else if(e.getSource() == fanta){
             String name = "Fanta";
            int price = 70;
            
            int quantity = Integer.parseInt(JOptionPane.showInputDialog("Enter the Quantity"));
            int tot = price * quantity;
            
            model = (DefaultTableModel)jTable1.getModel();
            model.addRow(new Object[]{
                name,
                price,
                quantity,
                tot,
            });
            int sum = 0;
            for(int i=0; i < jTable1.getRowCount(); i++){
                sum = sum + Integer.parseInt(jTable1.getValueAt(i, 3).toString());
            }
             txtsub.setText(Integer.toString(sum));
        }
        else if(e.getSource() == dew){
             String name = "Dew";
            int price = 70;
            
            int quantity = Integer.parseInt(JOptionPane.showInputDialog("Enter the Quantity"));
            int tot = price * quantity;
            
            model = (DefaultTableModel)jTable1.getModel();
            model.addRow(new Object[]{
                name,
                price,
                quantity,
                tot,
            });
            int sum = 0;
            for(int i=0; i < jTable1.getRowCount(); i++){
                sum = sum + Integer.parseInt(jTable1.getValueAt(i, 3).toString());
            }
             txtsub.setText(Integer.toString(sum));
        }
        
    }

    @Override
    public void mousePressed(MouseEvent e) {
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
       
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }
}
